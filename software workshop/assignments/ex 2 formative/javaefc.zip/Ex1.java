import java.util.Scanner;
import java.util.ArrayList;

public class Ex1 {
    public static void main (String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<String> inputs = new ArrayList<String>();

        do {
            System.out.println("Insert a string and press enter to submit. Insert 'quit' to stop.");
            inputs.add(scan.nextLine()); 
            
        } while (!inputs.get(inputs.size() - 1).toLowerCase().equals("quit"));

        System.out.println("You entered " + (inputs.size() - 1) + " strings.");
        System.out.println("These are your strings in order:");
        for (int i = 0; i < inputs.size(); i++) {
            if(!inputs.get(i).toLowerCase().equals("quit")){
                System.out.println(i+1 + ". " + inputs.get(i));
            }
        }
    }
}