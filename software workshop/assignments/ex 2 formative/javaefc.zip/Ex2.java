import java.util.Scanner;
import java.util.ArrayList;

public class Ex2 {
    public static void main (String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<String> inputs = new ArrayList<String>();

        do {
            System.out.println("Insert a string and press enter to submit. Insert 'quit' to stop.");
            inputs.add(scan.nextLine()); 
            
        } while(!inputs.get(inputs.size() - 1).toLowerCase().equals("quit"));

        boolean swapped = true;
        while(swapped == true) {
            swapped = false;
            for(int i = 1; i < inputs.size(); i++) {
                if(inputs.get(i - 1).length() > inputs.get(i).length()) {
                    String aux = inputs.get(i);
                    inputs.set(i, inputs.get(i - 1));
                    inputs.set(i - 1, aux);
                    swapped = true;
                }
            }
        }
        

        for(int i = 0; i < inputs.size(); i++) {
            if(!inputs.get(i).toLowerCase().equals("quit")){
                System.out.println(inputs.get(i));
            }
            
        }
        for(int i = inputs.size() - 1; i >= 0; i--) {
            if(!inputs.get(i).toLowerCase().equals("quit")){
                System.out.println(inputs.get(i));
            }
        }

        System.out.println("The longest string is: " + inputs.get(inputs.size()-1));
    }
}