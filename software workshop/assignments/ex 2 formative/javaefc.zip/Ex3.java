import java.util.Scanner;

public class Ex3 {
    public static void main(String[] args) {
        int matrix[][] = {{0, 1, 4, 5}, {3, 7, 9, 7}, {1, 8, 2, 1}};
        Scanner scan = new Scanner(System.in);

        showMatrix(matrix);

        do {
            System.out.println("Insert a number in the format 'xy' (a position in the matrix). Insert 'quit' to stop. ");
            try {
                final int POSITION_DIGIT_COUNT = 2;
                String input = scan.nextLine();
                if(input.length() != POSITION_DIGIT_COUNT) {
                    if(input.toLowerCase().equals("quit")) {
                        System.out.println("Game Over.");
                        System.out.println("The final matrix is: ");
                        showMatrix(matrix);
                        break;
                    } else {
                        System.out.println("Incorrect input.");
                        continue;
                    }
                }
                int rowIndex = Integer.parseInt("" + input.charAt(0));
                int columnIndex = Integer.parseInt("" + input.charAt(1));
                final int FIRST_XY = 0;
                final int LAST_X = 2;
                final int LAST_Y = 3;
                
                if(rowIndex < FIRST_XY || rowIndex > LAST_X || columnIndex < FIRST_XY || columnIndex > LAST_Y) {
                    System.out.println("Index out of bounds.");
                    continue;
                }
                System.out.println("The value in that position is: " + matrix[rowIndex][columnIndex]);
                System.out.println("The updated matrix is: ");
                matrix[rowIndex][columnIndex] = 0;
                showMatrix(matrix);

            } catch(Exception e) {
                System.out.println("Unmatched type.");
                scan = new Scanner(System.in);
            }
            


        } while (true);
        

    }

    public static int count (int number) {
        int count = 0;

        while (number != 0) {
            number /= 10;
            count++;
        }
        return count;
    }

    public static void showMatrix(int[][] matrix){
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 4; j++){
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
    }
}